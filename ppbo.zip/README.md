# PPBA - Player Psychological Behavior Analyzer
## Minecraft Paper 1.21.1 Plugin

A sophisticated plugin system that tracks player behavior (chat, combat) and uses AI (Claude API) to generate detailed psychological profiles for moderation and player behavior understanding.

**Target Version:** Minecraft Paper 1.21.1 (Java 21+)  
**API:** Anthropic Claude  
**Database:** SQLite  

---

## Features

✓ **Real-time chat tracking** - Logs player messages with context analysis  
✓ **Combat metrics** - Tracks PvP kills, deaths, and kill fairness  
✓ **AI-powered analysis** - Claude API generates psychological profiles  
✓ **Async processing** - Non-blocking API calls (no server lag)  
✓ **Color-coded reports** - In-game chat display with MiniMessage formatting  
✓ **Configurable retention** - Automatic cleanup of old data  
✓ **Permission-based** - Only staff can generate reports  

---

## Requirements

- **Java 21+** (Paper 1.21.1 requires Java 21)
- **Paper Server** 1.21.1 or latest
- **Anthropic Claude API key** (get from https://console.anthropic.com)
- **SQLite** (bundled with plugin via JDBC driver)

---

## Installation

### Step 1: Compile the Plugin

```bash
# Navigate to plugin directory
cd ppba-plugin

# Compile using Gradle
./gradlew build

# The compiled JAR will be in: build/libs/PPBA-2.1.0.jar
```

### Step 2: Install JAR

```bash
# Copy the JAR to your server's plugins folder
cp build/libs/PPBA-2.1.0.jar /path/to/server/plugins/

# Restart the server
# The plugin will create default config.yml on first run
```

### Step 3: Configure API Key

Edit `plugins/PPBA/config.yml`:

```yaml
api:
  api-key: "sk-ant-v7-..." # Replace with your actual Claude API key
  model: "claude-sonnet-4-6"
  timeout-seconds: 30
```

Get your API key from: https://console.anthropic.com/account/keys

### Step 4: Verify Installation

Restart your server. You should see:

```
═══════════════════════════════════════════
✓ PPBA Plugin loaded successfully!
Load time: XXXms
═══════════════════════════════════════════
```

---

## Usage

### Command: `/ppba <player_name> report`

Generate a psychological profile for a player.

**Permission:** `ppba.admin.report` (requires OP by default)

**Requirements:**
- Player must have at least 10 chat messages logged (configurable)
- Command is async - won't freeze the server

**Example:**

```
/ppba Ggsun report
```

**Output:**

```
═══════════════════════════════════════════
PLAYER PSYCHOLOGICAL PROFILE
Player: Ggsun
═══════════════════════════════════════════

[PLAYER PSYCHOLOGICAL PROFILE: Ggsun]
Primary Type: TYPE-01: Dignified Strategist
Confidence Score: 87%
Axis Scores: ER: 9/10 | EI: 7/10 | EF: 2/10 | SO: 6/10

Deep Behavioral Analysis:
- Communication Fingerprint: [analysis text]
- Trigger Points: [analysis text]
- Mask vs Reality Gap: [analysis text]
- Long-term Behavioral Prediction: [analysis text]

Plugin Backend Recommendation:
- Invisible Reputation Delta: +50
- Auto-Flag Tags: mentor_candidate, strategic_player
- Suggested Permission Tier: TRUSTED

═══════════════════════════════════════════
```

---

## Configuration (config.yml)

```yaml
database:
  type: "sqlite"                    # Database type (currently only SQLite)
  sqlite-path: "plugins/PPBA/data.db"
  max-chat-history: 100             # Maximum chat messages stored per player

api:
  provider: "claude"                # AI provider
  api-key: "YOUR_API_KEY_HERE"      # REQUIRED: Set your Claude API key
  model: "claude-sonnet-4-6"        # Claude model to use
  timeout-seconds: 30               # API timeout

analysis:
  min-data-points: 10               # Minimum messages needed for analysis
  enable-async: true                # Run API calls async (recommended)
  webhook-url: ""                   # Optional: send reports to webhook

privacy:
  mask-player-names-in-logs: false  # Hide names in log files
  log-reports-to-file: true         # Save reports to disk
  retention-days: 30                # Auto-delete old chat logs
```

---

## Personality Types

The plugin classifies players into 5 psychological types:

### TYPE-01: Dignified Strategist
- **Traits:** Logical, respectful, calm
- **Chat:** Minimal, purpose-driven ("GG", "Understood")
- **Reaction to loss:** Treats it as data, no rage

### TYPE-02: Toxic Instigator
- **Traits:** Aggressive, attention-seeking, low self-regulation
- **Chat:** CAPS LOCK, mocking, filter bypassing
- **Reaction to loss:** Blame-shifting, spam threats

### TYPE-03: Altruistic Guardian
- **Traits:** Empathetic, community-driven, helpful
- **Chat:** Welcomes newbies, mediates conflict
- **Reaction to loss:** Ignores own loss, helps others

### TYPE-04: Quiet Observer
- **Traits:** Independent, isolated, protective of privacy
- **Chat:** 1-2 word replies, minimal activity
- **Reaction to loss:** Silent disappearance

### TYPE-05: Anxious Validator
- **Traits:** Approval-seeking, insecure confidence
- **Chat:** Shares achievements constantly, asks for validation
- **Reaction to loss:** Over-apologizes, self-criticism

---

## Analysis Axes

Each player is scored 0-10 on these psychological dimensions:

| Axis | Measure | Low | High |
|------|---------|-----|------|
| **ER** | Emotional Regulation | Reactive, ragequits | Calm, logical |
| **EI** | Empathy Index | Selfish, mocking | Considerate, supportive |
| **EF** | Ego Fragility | Defensive on loss | Graceful defeat |
| **SO** | Social Orientation | Isolated, solo | Community-engaged |

---

## Database Schema

The plugin automatically creates these tables in SQLite:

### `players`
```sql
CREATE TABLE players (
  id INTEGER PRIMARY KEY,
  player_name TEXT NOT NULL UNIQUE,
  uuid TEXT NOT NULL UNIQUE,
  first_seen INTEGER,
  last_seen INTEGER,
  playtime_seconds INTEGER
)
```

### `chat_logs`
```sql
CREATE TABLE chat_logs (
  id INTEGER PRIMARY KEY,
  player_name TEXT,
  uuid TEXT,
  message TEXT,
  context TEXT,        -- aggressive, neutral, loss_reaction, positive, etc.
  timestamp INTEGER
)
```

### `combat_metrics`
```sql
CREATE TABLE combat_metrics (
  id INTEGER PRIMARY KEY,
  killer_name TEXT,
  killer_uuid TEXT,
  victim_name TEXT,
  kill_type TEXT,       -- fair_pvp, predatory, standard_pvp
  fair_context INTEGER, -- 1 = fair, 0 = unfair
  timestamp INTEGER
)
```

### `reports`
```sql
CREATE TABLE reports (
  id INTEGER PRIMARY KEY,
  player_name TEXT,
  report_content TEXT,
  timestamp INTEGER
)
```

---

## Permissions

| Permission | Description | Default |
|-----------|-------------|---------|
| `ppba.admin.report` | Generate psychological profiles | OP |
| `ppba.bypass.tracking` | Exempt from chat/combat tracking | False |

---

## Troubleshooting

### API Key Error
```
⚠ Claude API key not configured!
Set 'api.api-key' in config.yml
```
**Solution:** Edit `plugins/PPBA/config.yml` and add your Claude API key.

### Insufficient Data
```
✗ Insufficient data for analysis
Need: 10 messages | Have: 3
```
**Solution:** Player needs more chat activity. Lower `min-data-points` in config or wait for player to chat more.

### API Timeout
```
✗ Analysis failed: API request timeout
```
**Solution:** Increase `timeout-seconds` in config.yml or check your internet connection.

### Database Lock
```
Error: database is locked
```
**Solution:** Restart the server. If persists, delete `plugins/PPBA/data.db` and let plugin recreate it.

---

## Performance Notes

- **Async Processing:** All API calls run on separate threads (no server freeze)
- **Database:** SQLite is file-based and handles ~1000s of records easily
- **Chat Logging:** Minimal overhead (< 1ms per message)
- **API Calls:** 20-30 seconds per analysis (configured timeout)
- **Memory:** ~50-100MB for 1000+ player profiles

---

## Security & Privacy

⚠ **Important Notes:**

1. **API Key:** Keep your Claude API key private. Don't share it.
2. **Data Retention:** Chat logs are stored in SQLite on disk. Consider privacy laws (GDPR, etc.)
3. **Masking:** Enable `mask-player-names-in-logs` if needed for compliance
4. **Cleanup:** Old data auto-deletes after `retention-days` (default 30)

---

## Development Notes

### Project Structure
```
ppba-plugin/
├── src/main/java/com/ppba/plugin/
│   ├── PPBAPlugin.java              # Main plugin class
│   ├── commands/
│   │   └── PPBACommand.java         # Command handler
│   ├── listeners/
│   │   ├── ChatListener.java        # Chat event tracking
│   │   └── CombatListener.java      # Combat event tracking
│   ├── data/
│   │   ├── DataManager.java         # SQLite operations
│   │   └── PlayerProfile.java       # Data model
│   ├── api/
│   │   └── ClaudeAPIClient.java    # Claude API integration
│   ├── formatting/
│   │   └── ReportFormatter.java     # In-game report display
│   └── config/
│       └── Config.java              # Configuration handling
├── plugin.yml                        # Plugin metadata
├── build.gradle                      # Gradle build config
└── README.md                        # This file
```

### Building from Source
```bash
# Requires: Java 21+, Gradle

git clone <repo-url>
cd ppba-plugin
./gradlew build

# Output: build/libs/PPBA-2.1.0.jar
```

### Adding Features
1. Chat context analysis → Modify `ChatListener.analyzeMessageContext()`
2. Combat context analysis → Modify `CombatListener.analyzeKillContext()`
3. New personality types → Update system prompt in `ClaudeAPIClient`
4. Custom reporting → Extend `ReportFormatter`

---

## API Cost Estimation

Claude API pricing (as of 2024):
- **Input tokens:** $3 per 1M tokens
- **Output tokens:** $15 per 1M tokens

Average analysis:
- ~500 input tokens (player data + system prompt)
- ~500 output tokens (report)
- **Cost per report:** ~$0.006 (less than 1 cent)

---

## Support & Contributing

For issues, feature requests, or contributions:
- Create an issue on GitHub
- Include: server version, error logs, config (sanitized)
- Test reports before submitting

---

## License

[Add your license here]

---

## Changelog

### v2.1.0 (Current)
- Initial release
- Paper 1.21.1 support
- Claude API integration
- SQLite database
- 5-point personality classification

---

**Last Updated:** 2024
**Created for:** Ggsun's Minecraft Server
