# PPBA Plugin - Technical Architecture

## System Overview

```
┌─────────────────────────────────────────────────────────────┐
│                     MINECRAFT SERVER                         │
│                     (Paper 1.21.1)                           │
├──────────────────────┬──────────────────────┬────────────────┤
│                      │                      │                │
│   ChatListener       │   CombatListener     │  Command Handler
│   (AsyncChatEvent)   │   (PlayerDeathEvent) │  (/ppba report)
│                      │                      │                │
└──────────────┬───────┴──────────────┬───────┴────────┬──────┘
               │                      │                │
               └──────────────────────┼────────────────┘
                                      ▼
                           ┌──────────────────┐
                           │   DataManager    │
                           │   (SQLite ORM)   │
                           └────────┬─────────┘
                                    ▼
                        ┌───────────────────────┐
                        │ SQLite Database       │
                        │ - chat_logs           │
                        │ - combat_metrics      │
                        │ - players             │
                        │ - reports             │
                        └───────────────────────┘
                                    
        When `/ppba <player> report` is executed:
        
                          PPBACommand
                                │
                         PlayerProfile
                         (JSON formatted)
                                │
                                ▼
                        ┌──────────────────────┐
                        │  ClaudeAPIClient     │
                        │  (Async HTTP POST)   │
                        │ https://api.anthropic
                        └──────────┬───────────┘
                                   │
                                   ▼
                        ┌──────────────────────┐
                        │   Claude API v1/    │
                        │   messages endpoint  │
                        │  (System Prompt v2.1)│
                        └──────────┬───────────┘
                                   │
                                   ▼
                        Psychological Analysis
                        (JSON Response)
                                   │
                                   ▼
                        ┌──────────────────────┐
                        │  ReportFormatter     │
                        │  (MiniMessage Color) │
                        └──────────┬───────────┘
                                   │
                                   ▼
                        In-game Chat Display
                        (to CommandSender)
```

---

## Component Breakdown

### 1. **PPBAPlugin.java** - Lifecycle Manager
**Responsibility:** Plugin startup, shutdown, and dependency injection

```
onEnable():
  1. Load Config (config.yml)
  2. Initialize DataManager (SQLite connection)
  3. Initialize ClaudeAPIClient (API credentials)
  4. Register Commands (/ppba)
  5. Register Event Listeners (Chat, Combat)
  6. Schedule maintenance tasks (cleanup old logs)

onDisable():
  1. Close database connection
  2. Clean shutdown
```

**Key Methods:**
- `getInstance()` - Static accessor for singleton
- `getDataManager()` - Access to database operations
- `getApiClient()` - Access to Claude API

---

### 2. **ChatListener.java** - Event Tracking
**Responsibility:** Monitor and analyze player chat messages

```
Triggers on:
  - AsyncChatEvent (every chat message)
  - PlayerJoinEvent (player login)

Process:
  1. Extract plain text from Adventure component
  2. Analyze message context (aggressive, positive, etc.)
  3. Async log to SQLite
  4. Check trigger events (loss reaction, validation seeking, etc.)

Context Analysis:
  - Aggressive: Contains "trash", "noob", "rage", etc.
  - Loss Reaction: Contains "died", "unfair", "lag", etc.
  - Positive: Contains "thanks", "gg", "nice", etc.
  - Validation Seeking: Contains "did you see", "right?", etc.
  - Mocking: Contains "lol", "ez", "rekt", etc.
```

**Stored in:** `chat_logs` table

---

### 3. **CombatListener.java** - Combat Analysis
**Responsibility:** Track PvP kills and analyze kill fairness

```
Triggers on:
  - PlayerDeathEvent (when player dies)

Analyzes:
  - Is victim a new player? (< 1 hour playtime)
  - Is victim unarmed? (no items in hands)
  - Is kill in PvP zone? (can integrate with WorldGuard)
  - Health disparity? (killer much stronger?)

Classifies Kill As:
  - "fair_pvp" (designated PvP zone, armed victim)
  - "predatory" (new player OR unarmed victim)
  - "standard_pvp" (typical player-to-player)

Context Scoring:
  - If predatory: fairContext = false
  - If fair PvP: fairContext = true
  - Otherwise: fairContext = true (default)
```

**Stored in:** `combat_metrics` table

---

### 4. **PPBACommand.java** - Command Handler
**Responsibility:** Execute `/ppba <player> report` command

```
Execution Flow:
  1. Check permission (ppba.admin.report)
  2. Validate syntax (/ppba <name> report)
  3. Fetch player from database
  4. Check minimum data points (10 messages default)
  5. Send "analyzing..." message
  6. Run async analysis:
     a. Build JSON payload from PlayerProfile
     b. Call ClaudeAPIClient.analyzeBehavior()
     c. Wait for API response (async, non-blocking)
     d. Format report with ReportFormatter
     e. Send to CommandSender
     f. Log report to file (if enabled)

JSON Payload Structure:
{
  "player_name": "Ggsun",
  "uuid": "...",
  "first_seen": "2024-01-15",
  "last_seen": "2024-01-20",
  "total_playtime_hours": 42.5,
  "chat_history": [ ... ],
  "combat_metrics": {
    "kills": 15,
    "deaths": 3,
    "new_player_kills": 2,
    "unarmed_kills": 1,
    "pvp_zone_kills": 10
  }
}
```

---

### 5. **ClaudeAPIClient.java** - API Integration
**Responsibility:** HTTP communication with Claude API

```
Method: analyzeBehavior(playerDataJSON)

HTTP Request:
  POST https://api.anthropic.com/v1/messages
  
  Headers:
    - Content-Type: application/json
    - x-api-key: [API_KEY]
    - anthropic-version: 2023-06-01
  
  Body:
  {
    "model": "claude-sonnet-4-6",
    "max_tokens": 2000,
    "system": "[SYSTEM PROMPT v2.1]",
    "messages": [
      {
        "role": "user",
        "content": "Analyze this player data: [JSON]"
      }
    ]
  }

Response Parsing:
  1. Check HTTP 200 status
  2. Extract "text" field from JSON
  3. Unescape JSON characters
  4. Return analysis string

Error Handling:
  - Non-200 status → throw IOException
  - Timeout (30s default) → throw SocketTimeoutException
  - Invalid response → throw JSONParseException
```

**Threading:** Runs on async task (non-blocking)

---

### 6. **ReportFormatter.java** - Output Formatting
**Responsibility:** Convert raw API response to in-game display

```
Formatting Process:
  1. Parse raw report text by lines
  2. Detect section headers
  3. Apply color codes:
     - Red (§c): Toxic indicators, negative traits
     - Green (§a): Altruistic, Guardian, helpful
     - Gold (§6): Primary Type
     - Blue (§9): Axis Scores
     - Cyan (§d): Section headers
  
4. Build Component using Adventure API
  5. Send to CommandSender via chat

Output Structure:
  ═══════════════════════════════════════════
  PLAYER PSYCHOLOGICAL PROFILE
  Player: [Name]
  ═══════════════════════════════════════════
  
  [PLAYER PSYCHOLOGICAL PROFILE: ...]
  Primary Type: TYPE-XX: [Name]
  Confidence Score: XX%
  Axis Scores: ER: X/10 | EI: X/10 | EF: X/10 | SO: X/10
  
  Deep Behavioral Analysis:
  - Communication Fingerprint: [...]
  - Trigger Points: [...]
  - Mask vs Reality Gap: [...]
  - Long-term Behavioral Prediction: [...]
  
  Plugin Backend Recommendation:
  - Invisible Reputation Delta: [±value]
  - Auto-Flag Tags: [tags]
  - Suggested Permission Tier: [tier]
  
  ═══════════════════════════════════════════
```

---

### 7. **DataManager.java** - Database Operations
**Responsibility:** SQLite database abstraction layer

```
Core Operations:

initialize()
  - Load SQLite JDBC driver
  - Create connection
  - Create tables if not exist
  - Create indexes for performance

initializeOrUpdatePlayer(Player)
  - INSERT or UPDATE players table
  - Called on player join

logChatMessage()
  - INSERT into chat_logs
  - Async safe

logKill()
  - INSERT into combat_metrics
  - Stores kill_type and fair_context

getPlayerProfile(playerName)
  - SELECT * from players
  - SELECT * from chat_logs (last 100)
  - SELECT SUM() from combat_metrics
  - Return populated PlayerProfile object

playerExists(playerName)
  - Quick existence check

cleanupOldLogs(retentionDays)
  - DELETE chat_logs WHERE timestamp < cutoff
  - Called every 1 hour

shutdown()
  - Close connection gracefully
```

**Database Files:**
- `plugins/PPBA/data.db` - SQLite file
- Auto-created on first run

---

### 8. **PlayerProfile.java** - Data Model
**Responsibility:** Represent player data structure

```
Fields:
  - playerName: String
  - uuid: String
  - firstSeen: long (timestamp)
  - lastSeen: long (timestamp)
  - totalPlaytimeSeconds: long
  - chatHistory: List<ChatMessage>
  - kills, deaths, newPlayerKills, etc.: int

Methods:
  - getChatHistory() → List
  - addChatMessage(ChatMessage)
  - incrementKills(), incrementDeaths()
  - getKDRatio() → double
  - getTotalPlaytimeHours() → double
  - getMessageCount() → int
```

---

### 9. **Config.java** - Configuration Management
**Responsibility:** Load and validate configuration

```
Loads from: plugins/PPBA/config.yml

Parsed Values:
  - Database settings (type, path, max history)
  - API settings (provider, key, model, timeout)
  - Analysis settings (min data points, async, webhook)
  - Privacy settings (masking, logging, retention)

Validation:
  - Checks API key is set
  - Validates numeric ranges
  - Warns on suspicious settings

Accessible via:
  - Config.getApiKey()
  - Config.getMaxChatHistory()
  - Config.isAsyncEnabled()
  - Config.getRetentionDays()
  - etc.
```

---

## Data Flow Example

### Scenario: Admin runs `/ppba Ggsun report`

```
1. COMMAND EXECUTION
   Admin: /ppba Ggsun report
   
2. PERMISSION CHECK
   Server checks: player.hasPermission("ppba.admin.report")
   ✓ Pass
   
3. DATABASE FETCH
   DataManager.getPlayerProfile("Ggsun")
   Returns:
     - 85 chat messages (context: aggressive, positive, etc.)
     - 12 kills (3 predatory, 9 fair)
     - 2 deaths
     - 42.5 hours playtime
   
4. JSON PAYLOAD BUILD
   PPBACommand builds:
   {
     "player_name": "Ggsun",
     "chat_history": [
       {"message": "gg", "context": "positive"},
       {"message": "trash player", "context": "aggressive"},
       ...
     ],
     "combat_metrics": {
       "kills": 12,
       "new_player_kills": 3,
       ...
     }
   }
   
5. ASYNC API CALL
   Bukkit.runTaskAsynchronously() {
     ClaudeAPIClient.analyzeBehavior(jsonPayload)
       → HTTP POST to Claude API (30s timeout)
       → Receive psychological analysis
   }
   
6. RESPONSE PARSING
   Claude responds:
   """
   [PLAYER PSYCHOLOGICAL PROFILE: Ggsun]
   Primary Type: TYPE-01: Dignified Strategist
   Confidence Score: 87%
   Axis Scores: ER: 9/10 | EI: 7/10 | EF: 2/10 | SO: 6/10
   ...
   """
   
7. FORMAT & DISPLAY
   ReportFormatter.sendToCommandSender(sender)
   Displays in admin's chat with colors
   
8. LOGGING
   DataManager.logReport("Ggsun", fullReport)
   Saves to plugins/PPBA/reports/ or database
   
Total Time: ~30-35 seconds (async, no server freeze)
```

---

## Performance Considerations

### Memory Usage
- Per player profile: ~5-10 KB
- 1000 players: ~5-10 MB
- Full plugin runtime: 50-100 MB

### Database
- Chat logs: 100-500 bytes per message
- Combat metrics: ~200 bytes per kill
- Auto-cleanup after 30 days (configurable)

### API Calls
- Timeout: 30 seconds (configurable)
- Tokens per call: ~1000 (input + output)
- Cost: ~$0.006 per analysis

### Server Impact
- Chat logging: < 1ms overhead per message
- Combat logging: < 1ms overhead per kill
- API calls: Async (zero main thread impact)
- Database queries: < 10ms for fetch/store

---

## Security Best Practices

1. **API Key Storage**
   - Store in config.yml (server-side only)
   - Never log or transmit in plaintext
   - Use environment variables in production

2. **Data Privacy**
   - Chat logs contain player messages
   - Consider GDPR/privacy laws
   - Enable masking for sensitive data
   - Auto-delete old logs

3. **Command Permissions**
   - Restrict `/ppba` to admins/staff only
   - Permission: `ppba.admin.report`
   - No bypass for regular players

4. **Database Security**
   - SQLite file in protected directory
   - Regular backups recommended
   - Limit database access to plugin only

---

## Extension Points

### Add New Context Analysis
Edit `ChatListener.analyzeMessageContext()`:
```java
if (containsYourKeyword(lowerMessage)) {
    context = "your_context";
}
```

### Add New Combat Metrics
Edit `CombatListener.analyzeKillContext()`:
```java
context.customMetric = calculateCustomMetric(killer, victim);
```

### Add New Personality Types
Edit `ClaudeAPIClient.SYSTEM_PROMPT`:
```
TYPE-06: Your New Type
- Traits: [description]
- Chat: [indicators]
- Reaction: [behavior]
```

### Custom Report Formatting
Extend `ReportFormatter` class:
```java
public Component getCustomSection() {
    // Your formatting
}
```

---

## Troubleshooting Guide

| Issue | Cause | Solution |
|-------|-------|----------|
| API timeout | Network slow | Increase timeout in config |
| Database locked | File in use | Restart server |
| No reports generated | Insufficient data | Lower min-data-points |
| Colors not showing | Old Minecraft | Update to 1.21.1 |
| Permission denied | Not OP | Give ppba.admin.report |

---

## Future Enhancements

- [ ] MySQL/PostgreSQL support
- [ ] Webhook integration for external tools
- [ ] Real-time player reputation scores
- [ ] Automated moderation actions
- [ ] Web dashboard for reports
- [ ] Integration with other plugins (WorldGuard, etc.)
- [ ] Multi-language support
- [ ] Machine learning for behavior prediction
