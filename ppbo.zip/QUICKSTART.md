# PPBA Plugin - Quick Start Guide

## 5-Minute Setup

### Prerequisites
- Java 21+ installed (`java -version`)
- Paper 1.21.1 server running
- Claude API key (get from https://console.anthropic.com)

---

## Step 1: Build the Plugin (2 minutes)

```bash
# Clone or navigate to plugin directory
cd ppba-plugin

# Compile
./gradlew build

# The JAR is now at:
# build/libs/PPBA-2.1.0.jar
```

**Output:**
```
> Task :build UP-TO-DATE
> Task :assemble UP-TO-DATE

BUILD SUCCESSFUL in 5s
```

---

## Step 2: Install JAR (30 seconds)

```bash
# Copy to server
cp build/libs/PPBA-2.1.0.jar /path/to/server/plugins/

# Restart server
# (The plugin will auto-create config folder)
```

---

## Step 3: Configure API Key (30 seconds)

**File:** `plugins/PPBA/config.yml`

Change this:
```yaml
api:
  api-key: "YOUR_API_KEY_HERE"
```

To this (your actual key):
```yaml
api:
  api-key: "sk-ant-v7-xxxxxxxxxxxxxxxxxxxxx"
```

Save and restart server.

---

## Step 4: Test It (1 minute)

```
In-game as OP:
  /ppba Steve report

Expected output:
  ⟳ Analyzing player data...
  [After ~30 seconds]
  [PLAYER PSYCHOLOGICAL PROFILE: Steve]
  Primary Type: TYPE-03: Altruistic Guardian
  Confidence Score: 72%
  Axis Scores: ER: 7/10 | EI: 9/10 | EF: 3/10 | SO: 9/10
  ...
```

---

## Common Issues & Fixes

### "API key not configured"
```yaml
api:
  api-key: "sk-ant-v7-..." # ← Add your key here
```

### "Insufficient data for analysis"
Player needs at least 10 chat messages. Wait or lower in config:
```yaml
analysis:
  min-data-points: 5  # Lower threshold
```

### "Connection timeout"
Increase timeout:
```yaml
api:
  timeout-seconds: 60  # Was 30
```

### "Database is locked"
Restart server. Delete `plugins/PPBA/data.db` if needed.

---

## File Structure After Install

```
server/plugins/
├── PPBA-2.1.0.jar
└── PPBA/
    ├── config.yml
    ├── data.db (created on first run)
    ├── logs/
    │   └── reports/ (if log-reports-to-file enabled)
    └── logs.txt
```

---

## Command Reference

```bash
# Generate report for a player
/ppba <player_name> report

# Example:
/ppba Ggsun report
/ppba Steve report
/ppba Alex report
```

**Permission:** `ppba.admin.report` (OP by default)

---

## Report Output Example

```
═══════════════════════════════════════════
PLAYER PSYCHOLOGICAL PROFILE
Player: Ggsun
═══════════════════════════════════════════

[PLAYER PSYCHOLOGICAL PROFILE: Ggsun]
Primary Type: TYPE-01: Dignified Strategist
Secondary Traits: Mentor Potential
Confidence Score: 87%
Axis Scores: ER: 9/10 | EI: 7/10 | EF: 2/10 | SO: 6/10

Deep Behavioral Analysis:
- Communication Fingerprint: Minimal, purposeful language. Uses "GG" 
  in response to losses. No caps-lock rage or toxic vocabulary. 
  Demonstrates high emotional control.
  
- Trigger Points: Loses composure slightly during spawn-killing incidents 
  but recovers quickly. Respects player boundaries and agreements.
  
- Mask vs Reality Gap: Very small. Public behavior matches private 
  interaction logs. Consistent personality across contexts.
  
- Long-term Behavioral Prediction: Will continue strategic play, 
  mentor newer players, maintain respectful engagement.

Plugin Backend Recommendation:
- Invisible Reputation Delta: +75
- Auto-Flag Tags: mentor_candidate, trusted_player, strategic_thinker
- Suggested Permission Tier: MODERATOR_TRUSTED

═══════════════════════════════════════════
```

---

## Personality Types (Quick Reference)

| Type | Traits | Chat | Best For |
|------|--------|------|----------|
| **TYPE-01** | Logical, calm | Minimal, respectful | Moderators, builders |
| **TYPE-02** | Aggressive, toxic | CAPS, mocking | Watch list, monitoring |
| **TYPE-03** | Helpful, empathetic | Supporting others | Community helpers |
| **TYPE-04** | Quiet, isolated | 1-2 words | Solo players, devs |
| **TYPE-05** | Approval-seeking | Frequent sharing | New players, anxious |

---

## Configuration Cheat Sheet

```yaml
# Database
max-chat-history: 100           # Messages to store per player
retention-days: 30              # Auto-delete after X days

# API
api-key: "sk-ant-v7-..."        # Your Claude key (REQUIRED)
timeout-seconds: 30             # How long to wait for response
model: "claude-sonnet-4-6"      # Claude model version

# Analysis
min-data-points: 10             # Minimum messages needed
enable-async: true              # Don't freeze server (yes!)
webhook-url: ""                 # Leave blank unless using webhooks

# Privacy
mask-player-names-in-logs: false    # Hide names in files?
log-reports-to-file: true           # Save reports to disk?
```

---

## API Cost Estimate

```
Per Analysis Report:
  Input tokens:  ~500 (player data + system prompt)
  Output tokens: ~500 (analysis report)
  Cost: ~$0.006 (less than 1 cent)

Examples:
  100 reports/month  = $0.60
  1000 reports/month = $6.00
```

Very affordable for server moderation!

---

## Production Checklist

- [ ] Java 21+ installed
- [ ] Paper 1.21.1 server running
- [ ] Claude API key obtained and configured
- [ ] JAR copied to plugins folder
- [ ] Server restarted
- [ ] Tested with `/ppba <player> report`
- [ ] Reports generating correctly
- [ ] Backups scheduled (optional but recommended)

---

## Next Steps

1. **Monitor players:** Use `/ppba` to understand behavior
2. **Adjust permissions:** Set `min-data-points` based on your needs
3. **Review auto-flags:** Use recommendations for moderation decisions
4. **Backup data:** Schedule backups of `plugins/PPBA/data.db`
5. **Customize:** Edit system prompt for your server culture

---

## Getting Help

- Check `plugins/PPBA/logs/` for error messages
- Review `README.md` for detailed docs
- See `ARCHITECTURE.md` for technical details
- Enable debug mode: Add `debug: true` to config.yml

---

## That's It! 🎉

Your PPBA psychological analysis system is ready.

Start analyzing players:
```
/ppba playername report
```

Happy moderation!
